<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>SpellListen  -  Listen and learn to spell...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Word number..:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spelled correct by user:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The word-list is empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please write username...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit Yes/No...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you wish to exit?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> * Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SpellListen - Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Congratulations %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You finished you task...

Correct spelled:
%1 of %2 words.

Satisfied?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F2  : Open word list in sequence
F3  : Open word list out of sequence
F4  : Hear the word you are going to spell
F5  : Show/Hide letters to use in word
F8  : Fetch next word in wordfile
F10 : Exit program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SpellListen wordlist-files (*.stav)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
